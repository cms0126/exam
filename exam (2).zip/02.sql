POST /emp/_search
{
  "query": {
    "match_all": {}
  }
}