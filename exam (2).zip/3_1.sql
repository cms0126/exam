POST /employee/_search
{
  "size": 0,
  "aggs": {
    "tdno": {
      "terms": {
        "field": "dno"
      },
      "aggs": {
        "ssalary": {
          "sum": {
            "field": "salary"
          }
        }
      }
    },
    "total_salary":{
      "sum_bucket": {
        "buckets_path": "tdno>ssalary"
      }
    }
  }
}